// ===== Elements =====

let infiniteTime = 0; // seconds
let infiniteTimerInterval;


let userAnswers = [];
let checked = [];
let infiniteChecked = {}; // key = question text, value = true/false

let answered = false;

const questionImage = document.getElementById("questionImage");

const quizModeBtn = document.getElementById("quizModeBtn");
const infiniteModeBtn = document.getElementById("infiniteModeBtn");
const quizSelection = document.getElementById("quizSelection");
const quizTaking = document.getElementById("quizTaking");
const results = document.getElementById("results");
const modeSelection = document.getElementById("modeSelection");

const quizSelect = document.getElementById("quizSelect");
const startQuizBtn = document.getElementById("startQuizBtn");
const questionText = document.getElementById("questionText");
const choicesDiv = document.getElementById("choices");
const nextBtn = document.getElementById("nextButton");
const restartBtn = document.getElementById("restartBtn");
const timerDiv = document.getElementById("timer");
const scoreInfo = document.getElementById("scoreInfo");
const questionProgress = document.getElementById("questionProgress");
const progressFill = document.getElementById("progressFill");
const finalScore = document.getElementById("finalScore");
const timeSpent = document.getElementById("timeSpent");




const submitBtn = document.getElementById("submitBtn");
const submitModal = document.getElementById("submitModal");
const submitYes = document.getElementById("submitYes");
const submitNo = document.getElementById("submitNo");

const exitButton = document.getElementById("exitButton");
const modal = document.getElementById("modal");
const yesBtn = modal.querySelector(".modal-btn.yes");
const noBtn = modal.querySelector(".modal-btn.no");
const prevBtn = document.getElementById("prevButton");


const checkBtn = document.getElementById("checkBtn");

function showCheckButton() {
    checkBtn.classList.remove("hidden");
}

const explanationDiv = document.getElementById("explanation");
const resultMsg = document.getElementById("resultMsg");

// ===== Data =====
// Only showing a few questions as example; add the rest as you 



const infinitePool = [
  {
    question: "How many different pairs of 2 cookies can Aiden choose from a plate of 6 different cookies?",
    choices: ["15", "12", "10", "20"],
    answer: 0, // "15"
    explanation: "The number of ways to choose 2 cookies from 6 is given by the combination formula: C(6,2) = 6! / (2! × (6-2)!) = 15."
  },
   {
    question: "In the pyramid above, each triangular face has the same area, and the base ABCD is a square that measures 8 centimeters on each side. If the slant height of the pyramid is 6 centimeters, what is the surface area of the pyramid excluding the base?",
    choices: ["48 sq cm", "96 sq cm", "128 sq cm", "160 sq cm"],
    image: "https://i.imgur.com/Ew4b9Gk.png",
    answer: 1, // 96 sq cm
    explanation: "The surface area of the pyramid excluding the base is the area of the four triangular faces. The area of each triangular face is given by (1/2) × base × slant height. Since the base of the pyramid is 8 cm and the slant height is 6 cm, the area of one triangular face is (1/2) × 8 × 6 = 24 sq cm. There are 4 triangular faces, so the total surface area excluding the base is 24 × 4 = 96 sq cm."
  },
  {
  question: "What is the area of the shaded region in the graph above?",
 image: "https://i.imgur.com/kzYbecE.png",
    choices: ["m + n", "n - m", "2(n - m)", "4(n - m)"],
    answer: 2,
    explanation: "The base of the triangle runs from m to n, so its length is n − m. The height of the triangle is 4. Using the area formula (1/2 × base × height): (1/2) × (n − m) × 4 = 2(n − m)."
},
{
  question: "What is the mean score of the 10 students in the table above?",
  image: "https://i.imgur.com/b4XgF70.png",
  choices: ["22.5", "75", "77", "85"],
  answer: 2,  // "77" at index 2
  explanation: "To find the mean score, first find the total score: (85 × 4) + (75 × 4) + (65 × 2) = 340 + 300 + 130 = 770. Then, divide by the total number of students: 770 ÷ 10 = 77."
},

  {
  question: "How many more people in Center City walk to work than ride their bicycle to work?",
  choices: ["2,500", "2,700", "2,800", "3,000"],
  answer: 2,  // "2,800" at index 2
  image: "https://i.imgur.com/oa7P6CF.png",
  explanation: "Given that 22% walk and 4% bicycle, we know the total number of people is 10,000. The number of people who walk is 22% of 10,000 = 2,200, and the number of people who bicycle is 4% of 10,000 = 400. The difference is 2,200 - 400 = 2,800."

},

  {
    question: "Simplify: 5x - 2(3x - 4)",
    choices: ["-x + 8", "11x - 8", "x - 8", "x + 8"],
    answer: 0,  // "-x + 8"
    explanation: "5x - 6x + 8 = -x + 8"
  },
  {
    question: "How many of the 420 vehicles passed through the checkpoint contained at least 3 people?",
    image: "https://i.imgur.com/1UzB1Yo.png",
    choices: ["42", "63", "105", "315"],
    answer: 2, // 315
    explanation: "The number of vehicles with at least 3 people = 15% + 7% + 3% = 25% of 420 = 0.25 × 420 = 105."
  },
  {
    question: "Simplify: (4x³y²)(3x²y⁴)",
    choices: ["12x⁵y⁶", "7x⁵y⁶", "12x⁶y⁸", "12x⁵y⁸"],
    answer: 0, // "12x⁵y⁶"
    explanation: "Multiply coefficients 4×3=12; x³×x²=x⁵; y²×y⁴=y⁶"
  },
  {
    question: "The fuel mix for a small engine contains only gasoline and oil. If the mix requires 5 ounces of gasoline for every 6 ounces of oil, how many ounces of gasoline are needed to make 33 ounces of fuel mix?",
    choices: ["3", "6", "15", "27", "16 1/2"],
    answer: 2, // "15"
    explanation: "Total parts = 5+6=11; each part = 33/11=3; gasoline = 5×3=15 ounces"
  },
  {
    question: "Which of the following shows the fractions 11/3, 25/7, and 18/5 in order from least to greatest?",
    choices: ["25/7, 18/5, 11/3", "25/7, 11/3, 18/5", "18/5, 11/3, 25/7", "18/5, 25/7, 11/3", "11/3, 18/5, 25/7"],
    answer: 0, // "25/7, 18/5, 11/3"
    explanation: "Convert to decimals: 11/3 ≈3.667, 18/5=3.6, 25/7≈3.571 → order: 25/7, 18/5, 11/3"
  },
  {
    question: "A prom suit originally priced at $450 is on sale for 1/3 off the original price. In addition, Craig has a coupon for 10% off the discounted price. If there is a 6% sales tax on the final price, what would Craig’s total cost be?",
    choices: ["$111.30", "$143.10", "$270.30", "$286.20", "$297.00"],
    answer: 3, // "$286.20"
    explanation: "Discounted price = 450×(1-1/3)=300; coupon = 300×0.9=270; tax = 270×1.06=286.20"
  },
  {
    question: "A water tank is 1/3 full; then 21 gallons of water are added, making it 4/5 full. How many gallons of water could the tank hold if it were completely full?",
    choices: ["35 gal.", "45 gal.", "56 gal.", "84 gal.", "105 gal."],
    answer: 1, // "45 gal."
    explanation: "Let total = x; x*(4/5 - 1/3) = 21 → x*(12/15 - 5/15)=21 → x*(7/15)=21 → x=45 gal"
  },
  {
    question: "Today, Tom is 1/4 of Kiran’s age. In 2 years, Tom will be 1/3 of Kiran’s age. How old is Kiran today?",
    choices: ["4 yr", "6 yr", "12 yr", "16 yr", "22 yr"],
    answer: 3, // "16 yr"
    explanation: "Let K = Kiran’s age, T = K/4; in 2 years: (K/4 + 2) = (K + 2)/3, solve for K = 16."
  },
  {
    question: "In a scale drawing of a triangular banner, one side measures 16 centimeters and the other two sides each measure 12 centimeters. On the actual banner, these two sides each measure 36 feet. What is the length of the remaining side of the actual banner?",
    choices: ["48 feet", "90 feet", "96 feet", "102 feet"],
    answer: 0, // "48 feet"
    explanation: "The ratio of the sides in the scale drawing is 12:36, or 1:3. So, the remaining side in the drawing is 16 cm, which corresponds to 48 feet on the actual banner."
  },
  {
    question: "The faculty of a certain four-year college consists of 179 teachers. There are 663 first-year students. The student-to-faculty ratio for the entire college is 15 to 1. What is the total number of second-, third-, and fourth-year students?",
    choices: ["2,500", "2,022", "1,989", "2,700"],
    answer: 1, // "2,022"
    explanation: "The total number of students is 179 × 15 = 2,685. Subtracting the 663 first-year students gives 2,685 - 663 = 2,022."
  },
  {
    question: "What is the value of the expression: (21 ÷ 5) + (3 × 3) + (10 ÷ 4) - 2?",
    choices: ["12", "14", "16", "18"],
    answer: 1, // "14"
    explanation: "(21 ÷ 5) = 4.2, (3 × 3) = 9, (10 ÷ 4) = 2.5. So, 4.2 + 9 + 2.5 - 2 = 14."
  },
  {
    question: "A car is traveling 55 miles per hour, and 1 mile = 5,280 feet. Which of the following calculations would give the car’s speed in feet per second?",
    choices: ["55 × 5,280 ÷ 60", "55 × 5,280 ÷ 3600", "55 ÷ 60 × 5,280", "55 × 3600 ÷ 5,280"],
    answer: 1, // "55 × 5,280 ÷ 3600"
    explanation: "To convert from miles per hour to feet per second, multiply by 5,280 (feet per mile) and divide by 3,600 (seconds per hour)."
  },
  {
    question: "Scott leased a car for three years. He paid a one-time fee of $1,000, and an additional $300 per month for the full three years. At the end of the three years, what is the total amount Scott paid for leasing this car?",
    choices: ["$1,900", "$10,800", "$4,600", "$11,800"],
    answer: 3, // "$11,800"
    explanation: "Scott paid $1,000 one-time fee + $300 × 12 months × 3 years = $1,000 + $10,800 = $11,800."
  },
  {
    question: "For a presentation, Deion can create 5 slides in 20 minutes, working at a constant rate. Kyra can create 3 slides in 10 minutes, working at her own constant rate. What is the total number of slides the two of them can create in one hour?",
    choices: ["15", "16", "20", "33"],
    answer: 3, // "33"
    explanation: "Deion creates 5 slides in 20 minutes, so in 60 minutes, he creates 15 slides. Kyra creates 3 slides in 10 minutes, so in 60 minutes, she creates 18 slides. Together, they create 15 + 18 = 33 slides."
  },
  {
    question: "How many integers between 12 and 30 are multiples of neither 2 nor 3?",
    choices: ["6", "7", "8", "9"],
    answer: 0, // "6"
    explanation: "The numbers between 12 and 30 that are multiples of neither 2 nor 3 are 13, 17, 19, 23, 25, 29."
  },
  {
    question: "Let N = –(|–3| – |–8| + |–4|). What is the value of –|N|?",
    choices: ["–9", "–4", "–1", "1", "9"],
    answer: 2, // "–1"
    explanation: "|–3|=3, |–8|=8, |–4|=4 → 3−8+4 = −1 → N = −(−1) = 1 → −|N| = −1"
  },
  {
    question: "If 4x + 7 = 23, what is x?",
    choices: ["3", "4", "5", "6"],
    answer: 1, // "4"
    explanation: "4x = 23 - 7 → 4x = 16 → x = 4"
  },
  {
    question: "What is the area of a triangle with base 10 and height 5?",
    choices: ["15", "25", "30", "50"],
    answer: 1, // "25"
    explanation: "Area = 1/2 × base × height = 1/2 × 10 × 5 = 25"
  },
  {
    question: "Simplify: 3(2x + 4) - 5x",
    choices: ["x + 12", "6x + 12", "6x - 5x + 4", "x - 4"],
    answer: 0, // "x + 12"
    explanation: "3×2x=6x, 3×4=12, so 6x+12 - 5x = x + 12"
  },
  {
    question: "Solve: 2(x - 3) + 5 = 3x - 4",
    choices: ["x = 7", "x = 4", "x = 3", "x = 5"],
    answer: 2, // "x = 3"
    explanation: "2x-6+5=2x-1; 2x-1=3x-4 → -1+4=x → x=3. Correct answer: x=3"
  },
  {
    question: "What is the perimeter of a square with area 64?",
    choices: ["32", "16", "24", "8"],
    answer: 0, // "32"
    explanation: "Side = √64 = 8; perimeter = 4 × 8 = 32"
  },
  {
    question: "Simplify: 5a²b × 3ab²",
    choices: ["15a³b³", "8a²b³", "15a²b²", "8a³b²"],
    answer: 0, // "15a³b³"
    explanation: "Multiply coefficients: 5×3=15; a²×a = a³; b×b² = b³"
  },
  {
    question: "Factor: x² - 9",
    choices: ["(x - 3)(x + 3)", "(x - 9)(x + 1)", "(x - 1)(x + 9)", "(x - 2)(x + 5)"],
    answer: 0, // "(x - 3)(x + 3)"
    explanation: "Difference of squares: a² - b² = (a - b)(a + b)"
  },
    {
    question: "What is the area of the shaded triangle shown above?",
    image: "https://i.imgur.com/kzYbecE.png",
    choices: ["m + n", "n - m", "2(n - m)", "4(n - m)"],
    answer: 2,
    explanation: "The base of the triangle runs from m to n, so its length is n − m. The height of the triangle is 4. Using the area formula (1/2 × base × height): (1/2) × (n − m) × 4 = 2(n − m)."
  },
  {
    question: "Which animal pictured on a card has exactly a 1 in 4 chance of being picked at random from the box?",
    image: "https://i.imgur.com/d7CJC6x.png",
    choices: ["cat", "dog", "fish", "horse"],
    answer: 1,  // "dog" is at index 1
    explanation: "Total cards = 8 + 6 + 5 + 4 + 1 = 24. A 1 in 4 chance means 24 ÷ 4 = 6 cards. The animal with 6 cards is the dog."
  },
  {
    question: "Which number line below shows the solution set for y when (2x - 2 ≤ y ≤ 4x + 10) and (y = 1)?",
    choices: [
      { "image": "https://i.imgur.com/KgtOQhP.png" },
      { "image": "https://i.imgur.com/QXRbrDm.png" },
      { "image": "https://i.imgur.com/L0aFAK4.png" },
      { "image": "https://i.imgur.com/LPqm27R.png" }
    ],
    answer: 1,
    explanation: "Separate the compound inequality into two pieces:\n\n2x - 2 ≤ 1 ≤ 4x + 10\n\nFor the left side: 2x - 2 ≤ 1, solve for x:\n\n2x ≤ 3, so x ≤ 3/2\n\nFor the right side: 1 ≤ 4x + 10, solve for x:\n\n1 - 10 ≤ 4x, so −9 ≤ 4x, or x ≥ −9/4\n\nThe solution is −9/4 ≤ x ≤ 3/2.\n\nSo the number line showing this is the one with the solution between −9/4 and 3/2."
  },
  {
    question: "A drum is partially filled with oil. Currently, the drum is 1/4 full. How many kiloliters of oil need to be added in order to fill the drum completely?",
    choices: ["1.44", "2.88", "4.32", "14.10"],
    answer: 1,  // 2.88
    explanation: "If 1/4 is filled, then 3/4 is empty. Total volume = 3.84 kL (since 1/4 = 0.96). Oil to add = 3 × 0.96 = 2.88 kL."
  },
  {
    question: "Nicole’s age now is three times Carmen’s age. If Carmen will be 17 in two years, how old was Nicole 5 years ago?",
    choices: ["38 yr", "40 yr", "45 yr", "50 yr"],
    answer: 1, // 38 yr
    explanation: "Carmen is 15 now (17 - 2). Nicole is 3 × 15 = 45 now. Nicole 5 years ago: 45 - 5 = 40 years."
  },
  {
    question: "A chemical decays such that the amount left at the end of each week is 20% less than the amount at the beginning of that week. What percent of the original amount is left after two weeks?",
    choices: ["40%", "60%", "64%", "80%"],
    answer: 2,  // 40%
    explanation: "After 1 week, 80% remains. After 2 weeks, 0.8 × 0.8 = 0.64 (64%). The answer should be 64%."
  },
  {
    question: "Three students start running laps simultaneously. Ann completes 1 lap every 2 minutes, Jack every 3 minutes, Lee every 4 minutes. How many laps does Ann complete before all three are again at the start line together?",
    choices: ["4", "6", "12", "20"],
    answer: 1, // 12
    explanation: "LCM of 2, 3, 4 is 12 minutes. Ann completes 12 / 2 = 6 laps before they meet, so answer should be 6."
  },
  {
    question: "What is the probability that a student surveyed has at least 2 pets?",
    image: "https://i.imgur.com/XI5ac1H.png",
    choices: ["7/40", "1/4", "12/40", "3/40"],
    answer:2, // 12/40 (only 2 pets)
    explanation: "At least 2 pets = 7 + 5 = 12 students. Total = 12+16+7+5=40. Probability = 12/40."
  },
  {
    question: "A large container partially filled with n liters of water. Adding 10 liters makes it 60% full. Adding 6 more liters makes it 75% full. What is n?",
    choices: ["14", "15", "26", "30"],
    answer: 0, // 14
    explanation: "Let total volume = V.\n(n + 10) = 0.6V and (n + 16) = 0.75V.\nSubtracting: (n+16)-(n+10)=0.75V-0.6V → 6=0.15V → V=40.\nThen n+10=24 → n=14."
  },
];

const quizzes = [
  // Quiz 1
  [
    {
      question: "If 3x + 7 = 31, what is x?",
      choices: ["6", "8", "9", "10"],
      answer: 1, // "8"
      explanation: "3x = 31 - 7 → 3x = 24 → x = 8"
    },
    {
      question: "A rectangle has length 12 and width 7. What is its area?",
      choices: ["84", "72", "79", "90"],
      answer: 0, // "84"
      explanation: "Area = length × width = 12 × 7 = 84"
    },
    {
      question: "Simplify: 4(3x - 5) + 2x",
      choices: ["14x - 20", "12x - 20", "14x + 20", "10x - 5"],
      answer: 0, // "14x - 20"
      explanation: "4×3x = 12x, 4×-5 = -20, plus 2x = 12x + 2x - 20 = 14x - 20"
    },
    {
      question: "What is 15% of 200?",
      choices: ["20", "25", "30", "35"],
      answer: 2, // "30"
      explanation: "0.15 × 200 = 30"
    },
    {
      question: "Sum of three consecutive integers is 51. What is the middle integer?",
      choices: ["16", "17", "18", "19"],
      answer: 1, // "17"
      explanation: "Let integers be x-1, x, x+1; sum = 3x = 51 → x = 17"
    },
    {
      question: "Solve: 2(x - 3) + 5 = 3x - 4",
      choices: ["x = 7", "x = 4", "x = 3", "x = 5"],
      answer: 2, // "x = 3"
      explanation: " 2x-6+5=2x-1; 2x-1=3x-4 → -1+4=x → x=3. Correct answer: x=3"
    },
    {
      question: "What is the perimeter of a square with area 64?",
      choices: ["32", "16", "24", "8"],
      answer: 0, // "32"
      explanation: "Side = √64 = 8; perimeter = 4 × 8 = 32"
    },
    {
      question: "Simplify: 5a²b × 3ab²",
      choices: ["15a³b³", "8a²b³", "15a²b²", "8a³b²"],
      answer: 0, // "15a³b³"
      explanation: "Multiply coefficients: 5×3=15; a²×a = a³; b×b² = b³"
    },
    {
      question: "If the ratio of cats to dogs is 3:4 and there are 28 dogs, how many cats are there?",
      choices: ["21", "24", "18", "25"],
      answer: 0, // "21"
      explanation: "3:4 = x:28 → x = (3/4) × 28 = 21"
    },
    {
      question: "In the quarter circle shown, what is y in terms of x?",
      choices: ["x - 1", "x + 1", "(x + 1) / 2", "√((x + 1)² / 2)"],
      image: "https://i.imgur.com/OCGXpY5.png",
      answer: 0, // "x - 1"
      explanation: "The diagonal labeled x + 1 is the radius of the quarter circle. The total horizontal distance from the center to the edge is y + 2, which must equal the radius. So y + 2 = x + 1, and solving gives y = x - 1."
    }
  ],

  // Quiz 2
  [
    {
      question: "What is the smallest integer p that will make the product 540p a perfect square?",
      choices: ["13", "14", "15", "16"],
      answer: 2, // "15"
      explanation: "To make 540 a perfect square, we need to multiply it by 3 and 5 so the exponents of 3 and 5 become even. This gives us 2^2 * 3^4 * 5^2, making the product a perfect square. Therefore, p = 15."
    },
    {
      question: "Solve for x: 7x - 4 = 3x + 12",
      choices: ["4", "3", "5", "6"],
      answer: 0, // "4"
      explanation: "7x - 3x = 12 + 4 → 4x = 16 → x = 4"
    },
    {
      question: "What is the volume of a cube with side length 5?",
      choices: ["125", "75", "100", "25"],
      answer: 0, // "125"
      explanation: "Volume = side³ = 5³ = 125"
    },
    {
      question: "Simplify: 3(2x + 1) - 4(x - 2)",
      choices: ["2x + 11", "6x + 3", "2x - 5", "10x + 5"],
      answer: 0, // "2x + 11"
      explanation: "3(2x+1)-4(x-2)=6x+3-4x+8=2x+11"
    },
    {
      question: "What is 40% of 150?",
      choices: ["60", "75", "50", "45"],
      answer: 0, // "60"
      explanation: "0.40 × 150 = 60"
    },
    {
      question: "Sum of four consecutive even numbers is 84. What is the smallest number?",
      choices: ["18", "20", "21", "24"],
      answer: 0, // "18"
      explanation: "Let numbers be x, x+2, x+4, x+6; sum=4x+12=84 → 4x=72 → x=18"
    },
    {
      question: "If 5 pencils cost $3.50, how much do 12 pencils cost?",
      choices: ["$7.50", "$8.40", "$6.60", "$9.00"],
      answer: 1, // "$8.40"
      explanation: "Cost per pencil = 3.50/5 = 0.70; 12 × 0.70 = $8.40"
    },
    {
      question: "Convert 0.125 to a fraction.",
      choices: ["1/8", "1/4", "1/5", "1/6"],
      answer: 0, // "1/8"
      explanation: "0.125 = 1/8"
    },
    {
      question: "If the perimeter of a rectangle is 54 and the length is 15, what is the width?",
      choices: ["12", "14", "13", "11"],
      answer: 0, // "12"
      explanation: "Perimeter = 2(l + w) → 54=2(15+w) → w=12"
    },
    {
      question: "What is the median of the data set: 3, 7, 9, 15, 21?",
      choices: ["7", "9", "12", "15"],
      answer: 1, // "9"
      explanation: "Median = middle value of ordered data = 9"
    }
  ],

  // Quiz 3
  [
    {
      question: "Solve for x: 2(x + 4) = 3x - 2",
      choices: ["10", "8", "6", "12"],
      answer: 0, // "10"
      explanation: "2x+8=3x-2 → 10 = x"
    },
    {
      question: "What is the area of a circle with radius 7? (Use π ≈ 3.14)",
      choices: ["153.86", "144", "175.84", "150"],
      answer: 0, // "153.86"
      explanation: "Area = πr² = 3.14 × 7² = 3.14 × 49 = 153.86"
    },
    {
      question: "Three congruent circles with radii 2 cm are tangent to each other and divided into 4 congruent parts, as shown above. Find the distance AB.",
      image: "https://i.imgur.com/RBV8Ouv.png",
      choices: ["8√2", "6√2", "6√3", "4√2"],
      answer: 1, // "6√2"
      explanation: "Distance from A to the center of the third circle is 2 (radii) × 3 = 6 units. Distance from B to the center of the third circle is also 6 units. Using the Pythagorean theorem: 6² + 6² = 72, so the distance AB = √72 = 6√2."
    },
    {
      question: "What is 18% of 250?",
      choices: ["45", "48", "40", "50"],
      answer: 0, // "45"
      explanation: "0.18 × 250 = 45"
    },
    {
      question: "The sum of two numbers is 30, and their difference is 8. What are the numbers?",
      choices: ["19 and 11", "20 and 10", "18 and 12", "21 and 9"],
      answer: 0, // "19 and 11"
      explanation: "x+y=30, x-y=8 → x=19, y=11"
    },
    {
      question: "Factor: x² + 5x + 6",
      choices: ["(x + 2)(x + 3)", "(x + 1)(x + 6)", "(x - 2)(x - 3)", "(x - 1)(x - 6)"],
      answer: 0, // "(x + 2)(x + 3)"
      explanation: "Factors of 6 that sum to 5 are 2 and 3"
    },
    {
      question: "If a car travels 60 miles in 1.5 hours, what is its average speed in miles per hour?",
      choices: ["40", "45", "35", "50"],
      answer: 0, // "40"
      explanation: "Speed = distance / time = 60 ÷ 1.5 = 40 mph"
    },
    {
      question: "Convert 3/5 to a decimal.",
      choices: ["0.5", "0.6", "0.75", "0.8"],
      answer: 1, // "0.6"
      explanation: "3 ÷ 5 = 0.6"
    },
    {
      question: "What is the probability of rolling a 4 on a six-sided die?",
      choices: ["1/6", "1/4", "1/3", "1/2"],
      answer: 0, // "1/6"
      explanation: "1 favorable outcome out of 6"
    },
    {
      question: "What is the sum of the interior angles of a pentagon?",
      choices: ["540°", "360°", "720°", "450°"],
      answer: 0, // "540°"
      explanation: "Sum = (5-2)×180 = 540°"
    }
  ],

  // Quiz 4
  [
    {
      question: "The price of a sandwich was raised from $5.75 to $6.05. What was the approximate percent increase?",
      choices: ["5%", "7%", "6%", "8%"],
      answer: 0, // "5%"
      explanation: "Increase = 6.05-5.75=0.30; percent = (0.30/5.75)×100 ≈ 5.22% ≈ 5%"
    },
    {
      question: "Miles played 7 games with an average score of 9 points. If the average for the first 6 games was 8 points, what was his score in the seventh game?",
      choices: ["18", "20", "15", "12"],
      answer: 2, // "15"
      explanation: "Total points = 7×9=63; first 6 games = 6×8=48; 7th game = 63-48=15"
    },
    {
      question: "Daniella bought enough oranges to fill 5 bags. Each bag has 9 oranges. Total cost $13.50. How much for 54 oranges?",
      choices: ["$15.40", "$16.20", "$14.50", "$18.00"],
      answer: 1, // "$16.20"
      explanation: "Cost per orange = 13.50 ÷ (5×9)=0.30; 54×0.30=$16.20"
    },
    {
      question: "Calculate 6.3 ÷ 0.021",
      choices: ["300", "30", "0.3", "3"],
      answer: 0, // "300"
      explanation: "6.3 ÷ 0.021 = 300"
    },
    {
      question: "A tank with 700-gallon capacity has 80 gallons. Water is added at 7 gallons/min. After 50 min, what percent full is the tank?",
      choices: ["75%", "85%", "90%", "61.43%"],
      answer: 3, // "61.43%"
      explanation: "Water added = 7×50=350; total = 80+350=430; percent = (430/700)×100 ≈ 61.43%"
    },
    {
      question: "If a number is increased by 20% and then decreased by 25%, what is the overall percent change?",
      choices: ["-10%", "-5%", "-15%", "-20%"],
      answer: 0, // "-10%"
      explanation: "Overall multiplier = 1.20×0.75=0.90 → 10% decrease"
    },
    {
      question: "In the figure above, PQRS is a parallelogram. The measure of ∠PQT is 50°, and the measure of ∠PTQ is 70°. What is the measure of ∠QRS?",
      image: "https://i.imgur.com/L2DIAmO.png",
      choices: ["60°", "70°", "80°", "120°"],
      answer: 0, // "60°"
      explanation: "In triangle PQT, the angles sum to 180°. So ∠QPT = 180° − (50° + 70°) = 60°. In a parallelogram, opposite angles are equal, so ∠QRS = 60°."
    },
    {
      question: "What is the probability of drawing an ace from a standard deck of 52 cards?",
      choices: ["1/52", "1/13", "1/4", "4/52"],
      answer: 1, // "1/13"
      explanation: "4 aces / 52 cards = 1/13"
    },
    {
      question: "Solve for y: 3y + 2 = 2y + 7",
      choices: ["3", "4", "5", "6"],
      answer: 2, // "5"
      explanation: "3y - 2y = 7-2 → y=5"
    },
    {
      question: "What is the sum of the first 10 positive integers?",
      choices: ["55", "45", "65", "50"],
      answer: 0, // "55"
      explanation: "Sum = 10×11/2 = 55"
    }
  ],

  // Quiz 5
  [
    {
      question: "Solve: 5x + 2 = 17",
      choices: ["3", "5", "4", "6"],
      answer: 0, // "3"
      explanation: "5x = 17-2 → 5x=15 → x=3"
    },
    {
      question: "Simplify: 2(x+3) - 4(x-1)",
      choices: ["-2x+10", "2x+10", "-2x-10", "2x-10"],
      answer: 0, // "-2x+10"
      explanation: "2x+6-4x+4=-2x+10"
    },
    {
      question: "What is 25% of 80?",
      choices: ["20", "15", "25", "30"],
      answer: 0, // "20"
      explanation: "0.25×80=20"
    },
    {
      question: "A triangle has sides 7, 24, and 25. Is it a right triangle?",
      choices: ["Yes", "No", "Cannot tell", "Only sometimes"],
      answer: 0, // "Yes"
      explanation: "7²+24²=49+576=625=25² → Right triangle"
    },
    {
      question: "Factor: x² + 7x + 12",
      choices: ["(x+3)(x+4)", "(x+1)(x+12)", "(x+2)(x+6)", "(x+4)(x+4)"],
      answer: 0, // "(x+3)(x+4)"
      explanation: "Factors of 12 that sum to 7: 3 and 4"
    },
    {
      question: "Convert 0.2 to a fraction.",
      choices: ["1/2", "1/5", "1/4", "2/5"],
      answer: 1, // "1/5"
      explanation: "0.2 = 1/5"
    },
    {
      question: "Solve: 3(x-2)=9",
      choices: ["5", "4", "3", "6"],
      answer: 0, // "5"
      explanation: "3(x-2)=9 → x-2=3 → x=5"
    },
    {
      question: "What is the area of a square with side 9?",
      choices: ["81", "72", "90", "18"],
      answer: 0, // "81"
      explanation: "Area = side² = 9² = 81"
    },
    {
      question: "What is the greatest common factor of 18 and 24?",
      choices: ["6", "12", "8", "9"],
      answer: 0, // "6"
      explanation: "Factors of 18:1,2,3,6,9,18; 24:1,2,3,4,6,8,12,24 → GCF=6"
    },
    {
      question: "What is the least common multiple of 4 and 6?",
      choices: ["12", "24", "10", "6"],
      answer: 0, // "12"
      explanation: "Multiples of 4:4,8,12,...; multiples of 6:6,12,... → LCM=12"
    }
  ],

  // Quiz 6
  [
    {
      question: "Solve for x: 4x - 5 = 11",
      choices: ["4", "3", "2", "5"],
      answer: 0, // "4"
      explanation: "4x=16 → x=4"
    },
    {
      question: "Simplify: 6x - 3(2x -1)",
      choices: ["3", "6x+3", "0", "9x-3"],
      answer: 0, // "3"
      explanation: "6x-6x+3=3"
    },
    {
      question: "What is 10% of 250?",
      choices: ["25", "20", "30", "15"],
      answer: 0, // "25"
      explanation: "0.1×250=25"
    },
    {
      question: "A rectangle has length 10 and width 8. Find its perimeter.",
      choices: ["36", "32", "30", "40"],
      answer: 0, // "36"
      explanation: "Perimeter=2(10+8)=36"
    },
    {
      question: "Factor: x² + 5x + 6",
      choices: ["(x+2)(x+3)", "(x+1)(x+6)", "(x+3)(x+3)", "(x+6)(x+1)"],
      answer: 0, // "(x+2)(x+3)"
      explanation: "2×3=6 and 2+3=5"
    },
    {
      question: "Convert 0.75 to a fraction.",
      choices: ["3/4", "2/3", "1/2", "1/4"],
      answer: 0, // "3/4"
      explanation: "0.75=3/4"
    },
    {
      question: "Solve for y: 2y + 7 = 15",
      choices: ["4", "3", "5", "6"],
      answer: 0, // "4"
      explanation: "2y=15-7=8 → y=4"
    },
    {
      question: "What is the area of a triangle with base 10 and height 6?",
      choices: ["30", "60", "16", "36"],
      answer: 0, // "30"
      explanation: "Area = 1/2×base×height = 1/2×10×6=30"
    },
    {
      question: "If a die is rolled, probability of even number?",
      choices: ["1/2", "1/3", "1/4", "2/3"],
      answer: 0, // "1/2"
      explanation: "Even numbers: 2,4,6 → 3 outcomes out of 6 → 1/2"
    },
    {
      question: "Sum of interior angles of hexagon?",
      choices: ["720°", "540°", "360°", "600°"],
      answer: 0, // "720°"
      explanation: "Sum = (6-2)×180=720°"
    }
],
  // Quiz 7
[
  {
    question: "Solve for x: 5x + 3 = 23",
    choices: ["4", "5", "6", "7"],
    answer: 0, // "4"
    explanation: "5x=20 → x=4"
  },
  {
    question: "Simplify: 4(x+2)-3x",
    choices: ["x+8", "x+2", "7x+2", "x+6"],
    answer: 0, // "x+8"
    explanation: "4x+8-3x=x+8"
  },
  {
    question: "What is 12% of 50?",
    choices: ["6", "5", "7", "8"],
    answer: 0, // "6"
    explanation: "0.12×50=6"
  },
  {
    question: "Area of square with side 11?",
    choices: ["121", "111", "122", "100"],
    answer: 0, // "121"
    explanation: "Area=11²=121"
  },
  {
    question: "Factor: x² + 9x + 20",
    choices: ["(x+4)(x+5)", "(x+1)(x+20)", "(x+5)(x+5)", "(x+2)(x+10)"],
    answer: 0, // "(x+4)(x+5)"
    explanation: "4×5=20, 4+5=9"
  },
  {
    question: "Convert 0.6 to fraction.",
    choices: ["3/5", "2/3", "1/2", "1/3"],
    answer: 0, // "3/5"
    explanation: "0.6=3/5"
  },
  {
    question: "Solve: 3x - 7 = 11",
    choices: ["6", "5", "7", "4"],
    answer: 0, // "6"
    explanation: "3x=18 → x=6"
  },
  {
    question: "Perimeter of rectangle with length 9, width 4?",
    choices: ["26", "24", "28", "22"],
    answer: 0, // "26"
    explanation: "Perimeter=2(9+4)=26"
  },
  {
    question: "Probability of drawing a red card from standard deck?",
    choices: ["1/2", "1/3", "1/4", "2/3"],
    answer: 0, // "1/2"
    explanation: "26 red cards / 52 = 1/2"
  },
  {
    question: "Sum of interior angles of octagon?",
    choices: ["1080°", "900°", "720°", "1000°"],
    answer: 0, // "1080°"
    explanation: "Sum = (8-2)×180=1080°"
  }
],

// Quiz 8
[
  {
    question: "In a scale drawing of a rectangular garden, one side measures 18 centimeters and the other two sides each measure 14 centimeters. On the actual garden, these two sides each measure 42 feet. What is the length of the remaining side of the actual garden?",
    choices: ["54 feet", "96 feet", "102 feet", "108 feet"],
    answer: 0, // "54 feet"
    explanation: "The ratio of the sides in the scale drawing is 14:42, or 1:3. So, the remaining side in the drawing is 18 cm, which corresponds to 54 feet on the actual garden."
  },
  {
    question: "The faculty of a certain university consists of 190 professors. There are 700 first-year students. The student-to-faculty ratio for the entire university is 18 to 1. What is the total number of second-, third-, and fourth-year students?",
    choices: ["2,700", "2,200", "2,500", "2,100"],
    answer: 1, // "2,200"
    explanation: "The total number of students is 190 × 18 = 3,420. Subtracting the 700 first-year students gives 3,420 - 700 = 2,200."
  },
  {
    question: "What is the value of the expression: (28 ÷ 7) + (5 × 5) + (14 ÷ 2) - 3?",
    choices: ["18", "20", "22", "24"],
    answer: 1, // "20"
    explanation: "(28 ÷ 7) = 4, (5 × 5) = 25, (14 ÷ 2) = 7. So, 4 + 25 + 7 - 3 = 20."
  },
  {
    question: "A car is traveling 60 miles per hour, and 1 mile = 5,280 feet. Which of the following calculations would give the car’s speed in feet per second?",
    choices: ["60 × 5,280 ÷ 60", "60 × 5,280 ÷ 3600", "60 ÷ 60 × 5,280", "60 × 3600 ÷ 5,280"],
    answer: 1, // "60 × 5,280 ÷ 3600"
    explanation: "To convert from miles per hour to feet per second, multiply by 5,280 (feet per mile) and divide by 3,600 (seconds per hour)."
  },
  {
    question: "How many positive even factors of 72 are greater than 30 and less than 72?",
    choices: ["1", "2", "3", "4"],
    answer: 0, // "1"
    explanation: "The factors of 72 are 1, 2, 3, 4, 6, 8, 9, 12, 18, 24, 36, 72. The only even factor greater than 30 and less than 72 is 36."
  },
  {
    question: "Anvi leased a car for four years. She paid a one-time fee of $1,500, and an additional $350 per month for the full four years. At the end of the four years, what is the total amount Anvi paid for leasing this car?",
    choices: ["$16,900", "$15,400", "$17,100", "$18,500"],
    answer: 2, // "$17,100"
    explanation: "Anvi paid $1,500 one-time fee + $350 × 12 months × 4 years = $1,500 + $16,800 = $17,100."
  },
  {
    question: "How many different pairs of 3 cookies can Randy choose from a plate of 7 different cookies?",
    choices: ["21", "35", "28", "56"],
    answer: 1, // "35"
    explanation: "The number of ways to choose 3 cookies from 7 is given by the combination formula: C(7,3) = 7! / (3! × (7-3)!) = 35."
  },
  {
    question: "For a project, Diksha can create 6 slides in 15 minutes, working at a constant rate. Mashia can create 4 slides in 10 minutes, working at her own constant rate. What is the total number of slides the two of them can create in one hour?",
    choices: ["30", "35", "32", "48"],
    answer: 3, // "48"
    explanation: "Diksha creates 6 slides in 15 minutes, so in 60 minutes, she creates 24 slides. Mashia creates 4 slides in 10 minutes, so in 60 minutes, she creates 24 slides. Together, they create 24 + 24 = 48 slides."
  },
  {
    question: "How many integers between 15 and 40 are multiples of neither 2 nor 5?",
    choices: ["6", "7", "8", "9"],
    answer: 1, // "7"
    explanation: "The numbers between 15 and 40 that are multiples of neither 2 nor 5 are 17, 19, 23, 27, 29, 31, 37."
  },
  {
    question: "A metal plate used in an electronic device must have a thickness of 0.02 inch, with an allowable error of 1 percent. What is the greatest allowable thickness of the metal plate?",
    choices: ["0.0002 in.", "0.02 in.", "0.0202 in.", "0.03 in."],
    answer: 2, // "0.0202 in."
    explanation: "1% of 0.02 is 0.0002. The greatest allowable thickness is 0.02 + 0.0002 = 0.0202 inches."
  }
],
//Quiz 9
  // Quiz 9
[
  {
    question: "What is the area of the shaded triangle shown above?",
    image: "https://i.imgur.com/kzYbecE.png",
    choices: ["m + n", "n - m", "2(n - m)", "4(n - m)"],
    answer: 2,
    explanation: "The base of the triangle runs from m to n, so its length is n − m. The height of the triangle is 4. Using the area formula (1/2 × base × height): (1/2) × (n − m) × 4 = 2(n − m)."
  },
  {
    question: "Which animal pictured on a card has exactly a 1 in 4 chance of being picked at random from the box?",
    image: "https://i.imgur.com/d7CJC6x.png",
    choices: ["cat", "dog", "fish", "horse"],
    answer: 1,  // "dog" is at index 1
    explanation: "Total cards = 8 + 6 + 5 + 4 + 1 = 24. A 1 in 4 chance means 24 ÷ 4 = 6 cards. The animal with 6 cards is the dog."
  },
  {
    question: "Which number line below shows the solution set for y when (2x - 2 ≤ y ≤ 4x + 10) and (y = 1)?",
    choices: [
      { "image": "https://i.imgur.com/KgtOQhP.png" },
      { "image": "https://i.imgur.com/QXRbrDm.png" },
      { "image": "https://i.imgur.com/L0aFAK4.png" },
      { "image": "https://i.imgur.com/LPqm27R.png" }
    ],
    answer: 1,
    explanation: "Separate the compound inequality into two pieces:\n\n2x - 2 ≤ 1 ≤ 4x + 10\n\nFor the left side: 2x - 2 ≤ 1, solve for x:\n\n2x ≤ 3, so x ≤ 3/2\n\nFor the right side: 1 ≤ 4x + 10, solve for x:\n\n1 - 10 ≤ 4x, so −9 ≤ 4x, or x ≥ −9/4\n\nThe solution is −9/4 ≤ x ≤ 3/2.\n\nSo the number line showing this is the one with the solution between −9/4 and 3/2."
  },
  {
    question: "A drum is partially filled with oil. Currently, the drum is 1/4 full. How many kiloliters of oil need to be added in order to fill the drum completely?",
    choices: ["1.44", "2.88", "4.32", "14.10"],
    answer: 1,  // 2.88
    explanation: "If 1/4 is filled, then 3/4 is empty. Total volume = 3.84 kL (since 1/4 = 0.96). Oil to add = 3 × 0.96 = 2.88 kL."
  },
  {
    question: "Nicole’s age now is three times Carmen’s age. If Carmen will be 17 in two years, how old was Nicole 5 years ago?",
    choices: ["38 yr", "40 yr", "45 yr", "50 yr"],
    answer: 1, // 38 yr
    explanation: "Carmen is 15 now (17 - 2). Nicole is 3 × 15 = 45 now. Nicole 5 years ago: 45 - 5 = 40 years."
  },
  {
    question: "A chemical decays such that the amount left at the end of each week is 20% less than the amount at the beginning of that week. What percent of the original amount is left after two weeks?",
    choices: ["40%", "60%", "64%", "80%"],
    answer: 0,  // 40%
    explanation: "After 1 week, 80% remains. After 2 weeks, 0.8 × 0.8 = 0.64 (64%). The answer should be 64%, so index 2."
  },
  {
    question: "Three students start running laps simultaneously. Ann completes 1 lap every 2 minutes, Jack every 3 minutes, Lee every 4 minutes. How many laps does Ann complete before all three are again at the start line together?",
    choices: ["4", "6", "12", "20"],
    answer: 2, // 12
    explanation: "LCM of 2, 3, 4 is 12 minutes. Ann completes 12 / 2 = 6 laps before they meet, so answer should be 6 (index 1)."
  },
  {
    question: "What is the probability that a student surveyed has at least 2 pets?",
    image: "https://i.imgur.com/XI5ac1H.png",
    choices: ["7/40", "1/4", "12/40", "3/40"],
    answer:2, // 12/40 (only 2 pets)
    explanation: "At least 2 pets = 7 + 5 = 12 students. Total = 12+16+7+5=40. Probability = 12/40."
  },
  {
    question: "A large container partially filled with n liters of water. Adding 10 liters makes it 60% full. Adding 6 more liters makes it 75% full. What is n?",
    choices: ["14", "15", "26", "30"],
    answer: 2, // 26
    explanation: "Let total volume = V.\n(n + 10) = 0.6V and (n + 16) = 0.75V.\nSubtracting: (n+16)-(n+10)=0.75V-0.6V → 6=0.15V → V=40.\nThen n+10=24 → n=14."
  },
  {
    question: "A box contains 5 strawberry candies, 3 banana candies, and 2 orange candies. If Vienna selects 2 candies at random from this box, without replacement, what is the probability that both candies are not banana?",
    choices: ["1/9", "7/9", "1/4", "4/7"],
    answer: 1,  // 7/9
    explanation: "Total number of candies = 5 + 3 + 2 = 10. The probability of selecting a non-banana candy on the first draw is (5 + 2) / 10 = 7/10. After removing one non-banana candy, there are 9 candies left, and 6 non-banana candies. The probability of selecting a non-banana candy on the second draw is 6/9. So, the overall probability is (7/10) × (6/9) = 42/90 = 7/9."
  },
],
 //Quiz 9
  // Quiz 10
[
  {
    question: "The Chens spend $5 of every $8 they earn on planned expenses. If the family earns $29,600 yearly, how much will they spend on planned expenses?",
    choices: ["$1,850", "$3,700", "$5,920", "$18,500"],
    answer: 3, // $18,500
    explanation: "Spend = (5/8) × 29600 = 18500."
  },
  {
    question: "The set of possible values of m is {5, 7, 9}. What is the set of possible values of k if k = 2m + 3?",
    choices: ["{3, 4, 5}", "{4, 5, 6}", "{8, 10, 12}", "{10, 14, 18}"],
    answer: 2, // {8, 10, 12}
    explanation: "Substitute each value of m into k = 2m + 3. When m = 5, k = 2(5) + 3 = 13. When m = 7, k = 2(7) + 3 = 17. When m = 9, k = 2(9) + 3 = 21."
  },
  {
    question: "In a certain school, course grades range from 0 to 100. Adrianna took 4 courses and her mean course grade was 90. Roberto took 5 courses. If both students have the same sum of course grades, what was Roberto’s mean?",
    choices: ["72", "80", "90", "92"],
    answer: 1, // 80
    explanation: "Adrianna's total grade = 4 × 90 = 360. Roberto’s total grade is the same, 360. With 5 courses, Roberto’s mean = 360 ÷ 5 = 80."
  },
  {
    question: "Jenny starts a game with twice as many marbles as Keiko. Jenny gives Keiko 5 marbles, but she still has 10 more than Keiko. How many marbles did Jenny have to start with?",
    choices: ["25", "30", "35", "40"],
    answer: 2, // 35
    explanation: "Let Keiko’s marbles be x. Jenny has 2x marbles. After giving 5 marbles to Keiko, Jenny has 2x - 5, and Keiko has x + 5. The equation becomes 2x - 5 = x + 5 + 10. Solving for x gives x = 15, so Jenny started with 30 marbles."
  },
  {
    question: "In a scale diagram, 0.125 inch represents 125 feet. How many inches represent 1 foot?",
    choices: ["0.001", "0.01", "0.1", "0.12"],
    answer: 1, // 0.01
    explanation: "If 0.125 inch = 125 feet, then 1 foot = 0.125 ÷ 125 = 0.01 inch."
  },
     {
    question: "An unmarked straight stick will be laid end over end to measure a distance of exactly 72 feet. The same stick will be used in the same way to measure a distance of exactly 30 feet. What is the length of the longest possible stick that can be used for both measurements?",
    choices: ["3 ft", "4 ft", "6 ft", "8 ft"],
    answer: 2, // 6 ft
    explanation: "The length of the stick must be a divisor of both 72 and 30. The greatest common divisor (GCD) of 72 and 30 is 6. Therefore, the longest possible stick that can be used for both measurements is 6 feet."
  },
  {
    question: "The perimeter of a rectangle is 510 centimeters. The ratio of the length to the width is 3:2. What are the dimensions of this rectangle?",
    choices: ["150 cm by 105 cm", "153 cm by 102 cm", "158 cm by 97 cm", "165 cm by 90 cm"],
    answer: 1, // 153 cm by 102 cm
    explanation: "Let the length be 3x and the width be 2x. The perimeter of the rectangle is 2(length + width) = 510. So, 2(3x + 2x) = 510, which gives x = 51. So, the length is 153 cm and the width is 102 cm."
  },
  {
    question: "The sum of the numbers x, y, and z is 50. The ratio of x to y is 1:4, and the ratio of y to z is 4:5. What is the value of y?",
    choices: ["4", "8", "10", "20"],
    answer: 2, // 10
    explanation: "Let x = k, y = 4k, and z = 5k. Then x + y + z = 50, so k + 4k + 5k = 50, or 10k = 50, so k = 5. Therefore, y = 4k = 4 × 5 = 20."
  },
  {
    question: "A box of colored pencils contains exactly 6 red pencils. The probability of choosing a red pencil from the box is 2/5. How many of the pencils in the box are not red?",
    choices: ["5", "15", "21", "30"],
    answer: 2, // 21
    explanation: "Let the total number of pencils be x. The probability of picking a red pencil is 6/x = 2/5. Solving for x gives x = 15. So, the number of non-red pencils is 15 - 6 = 9."
  },
  {
    question: "1 dollar = 7 lorgs and 1 dollar = 0.5 dalt. Kevin has 140 lorgs and 16 dalts. If he exchanges the lorgs and dalts for dollars according to the rates above, how many dollars will he receive?",
    choices: ["$28", "$52", "$182", "$28"],
    answer: 1, // $52
    explanation: "Kevin has 140 lorgs, which is 140 ÷ 7 = 20 dollars. He also has 16 dalts, which is 16 ÷ 0.5 = 32 dollars. Total = 20 + 32 = $52."
  },
],
  
  ];


function isCorrectAnswer(question, selectedIndex) {
  return selectedIndex === question.answer;
}


let mode = "";
let currentQuiz = [];
let index = 0;
let score = 0;
let time = 0;
let timerInterval;


// ===== Populate quiz selector =====
quizzes.forEach((_, i) => {
  const opt = document.createElement("option");
  opt.value = i;
  opt.textContent = `Quiz ${i + 1}`;
  quizSelect.appendChild(opt);
});

// ===== Timer =====
function startTimer() {
  clearInterval(timerInterval);
  time = 10 * 60; // 10 minutes in seconds
  updateTimerDisplay();

  timerInterval = setInterval(() => {
    time--;
    updateTimerDisplay();
    if (time <= 0) {
      clearInterval(timerInterval);
      finishQuiz(); // auto-submit when time is up
    }
  }, 1000);
}

function updateTimerDisplay() {
  const m = String(Math.floor(time / 60)).padStart(2, "0");
  const s = String(time % 60).padStart(2, "0");
  timerDiv.textContent = `${m}:${s}`;
}


function stopTimer() {
  clearInterval(timerInterval);
}

// ===== Mode selection =====
quizModeBtn.onclick = () => {
  mode = "quiz";
  modeSelection.classList.add("hidden");
  quizSelection.classList.remove("hidden");
};

infiniteModeBtn.onclick = () => {
  mode = "infinite";
  modeSelection.classList.add("hidden");
  quizTaking.classList.remove("hidden");
  
  // Reset score, totalAnswered, and accuracy bar
  score = 0;
  totalAnswered = 0;
  updateAccuracyBar(); // Update the accuracy bar visually

  startQuiz(infinitePool);

  // Start Infinite Mode stopwatch
  startInfiniteTimer();
};


// ===== Start quiz =====
startQuizBtn.onclick = () => {
  currentQuiz = quizzes[quizSelect.value];
  startQuiz(currentQuiz);
};





// ===== Show question =====



// In infinite mode, just increment score and show a new question when Next is clicked



// ===== Select answer =====
// ===== Select answer (NEW) =====
// ===== Select answer (NEW) =====
// ===== Select answer (NEW) =====


// In the fixed version, we ensure that the `answered` state is reset before each new question










// ===== Navigation buttons =====
// ===== Hide navigation buttons on page load =====
submitBtn.style.display = "none"; // hide submit initially



// ===== Navigation buttons =====
function updateNavigationButtons() {
  if (mode !== "quiz") return;

  // Previous button
  prevBtn.style.display = index === 0 ? "none" : "inline-block";

  // Next / Submit logic
  if (index === currentQuiz.length - 1) {
    nextBtn.style.display = "none";
    submitBtn.style.display = "inline-block";
  } else {
    nextBtn.style.display = "inline-block";
    submitBtn.style.display = "none";
  }
}



// ===== Next button =====


// ===== Submit button =====
submitBtn.onclick = () => {
  submitModal.classList.remove("hidden");
};

// ===== YES button =====
submitYes.onclick = () => {
  submitModal.classList.add("hidden"); // close modal
  submitBtn.classList.add("hidden");   // hide submit button
  calculateQuizScore();                 // ✅ calculate score for last question
  finishQuiz();                        // go to results
};

// ===== NO button =====
submitNo.onclick = () => {
  submitModal.classList.add("hidden"); // just close modal
  
  // After updating score
if (mode === "infinite") {
  scoreInfo.textContent = `Score: ${score}`;
} else {
  scoreInfo.textContent = `Score: ${score} / ${currentQuiz.length}`;
}

};


// ===== Finish quiz =====
function finishQuiz() {
  stopTimer();
  quizTaking.classList.add("hidden");
  results.classList.remove("hidden");
  finalScore.textContent = `${score} / ${currentQuiz.length}`;

  const minutes = String(Math.floor(time / 60)).padStart(2, "0");
  const seconds = String(time % 60).padStart(2, "0");
  timeSpent.textContent = `${minutes}:${seconds}`;
}

// ===== Restart =====
restartBtn.onclick = () => {
  quizSelection.classList.add("hidden");
  quizTaking.classList.add("hidden");
  results.classList.add("hidden");
  modeSelection.classList.remove("hidden");
  mode = "";
  currentQuiz = [];
  index = 0;
  score = 0;
  time = 0;
  stopTimer();
  totalAnswered = 0;
  updateAccuracyBar(); // Reset the bar visually too

  timerDiv.textContent = "00:00";
};

let totalAnswered = 0; // New variable to track the total number of answered questions

// For the 'check' button in Infinite Mode (only check answer, no score update yet)
// For the 'check' button in Infinite Mode (only check answer, no score update yet)
checkBtn.onclick = () => {
    const q = mode === "infinite"
        ? infinitePool.find(item => item.question === questionText.textContent)
        : currentQuiz[index];

    // Get selected answer
    const selectedAnswer = mode === "infinite" ? tempAnswer : userAnswers[index];

    // Fix here: check properly for no answer selected
    if (selectedAnswer === null || selectedAnswer === undefined) return;

    answered = true;

    // Disable all choice buttons
    document.querySelectorAll(".choice-btn").forEach(b => b.disabled = true);

   const letters = ['A.', 'B.', 'C.', 'D.'];  // Put this once globally

if (selectedAnswer === q.answer) {
    resultMsg.textContent = "✅ Correct!";
    resultMsg.style.color = "green";
} else {
    const correctLetter = letters[q.answer] || "?";
    const correctChoiceText = typeof q.choices[q.answer] === "string" 
        ? q.choices[q.answer] 
        : "(image)";

    resultMsg.textContent = `❌ Incorrect! Correct answer: ${correctLetter} ${correctChoiceText}`;
    resultMsg.style.color = "red";
}


    explanationDiv.textContent = q.explanation;
    explanationDiv.classList.remove("hidden");

    if (mode === "infinite") {
        infiniteChecked[q.question] = true;
    } else {
        checked[index] = true;
    }

    checkBtn.classList.add("hidden");
};


// For 'Next' button in Infinite Mode (increment totalAnswered and update score here)
// For 'Next' button in Infinite Mode (increment totalAnswered and update score here)
nextBtn.onclick = () => {
    if (mode === "infinite") {
        // If no answer is selected, treat it as skipped (increment totalAnswered but no score)
            if (tempAnswer === null) {
   
            totalAnswered++;

            // Update accuracy bar (this skipped question is considered wrong)
            updateAccuracyBar();
        } else {
            // If an answer was selected, treat it as a regular answer
            const currentQ = infinitePool.find(item => item.question === questionText.textContent);
            if (tempAnswer === currentQ.answer) {
                score++; // Increment score if the answer is correct
            }
            totalAnswered++; // Increment totalAnswered for answered question (whether right or wrong)
        }

        // Update score display
        scoreInfo.textContent = `Score: ${score} / ${totalAnswered}`;

        // Reset tempAnswer for the next question
        tempAnswer = null;

        // Pick a new random question (ensure it's not already answered)
        const unchecked = infinitePool.filter(item => !infiniteChecked[item.question]);
        const randomQ = unchecked.length > 0 ? unchecked[Math.floor(Math.random() * unchecked.length)] : infinitePool[Math.floor(Math.random() * infinitePool.length)];
        showQuestion([randomQ]);

        return;
    }

    // Normal quiz mode logic (same as before)
    calculateQuizScore();
    index++;
    if (index >= currentQuiz.length) finishQuiz();
    else showQuestion(currentQuiz);
};




// ===== Exit modal =====
// ===== Exit Modal =====
exitButton.onclick = () => modal.classList.remove("hidden");
yesBtn.onclick = () => {
  quizSelection.classList.add("hidden");
  quizTaking.classList.add("hidden");
  results.classList.add("hidden");
  modeSelection.classList.remove("hidden");
  mode = "";
  currentQuiz = [];
  index = 0;
  score = 0;
  time = 0;

  // Stop and reset timers
  stopTimer();           // Quiz mode timer
  stopInfiniteTimer();   // Infinite mode timer
  infiniteTime = 0;

  timerDiv.textContent = "00:00"; 
  modal.classList.add("hidden");
};

noBtn.onclick = () => modal.classList.add("hidden");

// ===== Start Quiz =====
// ===== Start Quiz =====
// ===== Global variable for Infinite Mode temporary answer =====

// ===== Start Quiz Function =====
// ===== Global variables =====
let tempAnswer = null; // only for infinite mode


// ===== Start Quiz =====
function startQuiz(quiz) {
  submitBtn.style.display = mode === "infinite" ? "none" : "inline-block"; // Show submit button for quiz mode only
  scoreInfo.style.display = mode === "infinite" ? "block" : "none";         // Show score for infinite mode

  index = 0;
  score = 0;

  if (mode === "infinite") {
    infiniteChecked = {}; // Track checked questions in infinite mode
    infiniteAnswered = 0; // Reset answered questions count
    tempAnswer = null;
  } else {
    userAnswers = new Array(quiz.length).fill(null);
    checked = new Array(quiz.length).fill(false);
  }

  quizSelection.classList.add("hidden");
  quizTaking.classList.remove("hidden");

  // Reset timer for quiz mode and hide it in infinite mode
  if (mode === "quiz") {
    startTimer();  // Start the timer for quiz mode
    time = 10 * 60; // Reset to 10 minutes for quiz mode
    timerDiv.textContent = "10:00"; // Start the countdown timer
  } else {
    time = 0;
    timerDiv.textContent = "00:00";  // No timer in infinite mode
  }

  showQuestion(quiz); // Show the first question

  // Update the visibility of the progress and accuracy bars based on the mode
  if (mode === "quiz") {
    progressFill.style.display = "block";  // Show progress bar in quiz mode
    accuracyBar.style.display = "none";   // Hide accuracy bar in quiz mode
  } else {
    progressFill.style.display = "none";  // Hide progress bar in infinite mode
    accuracyBar.style.display = "block"; // Show accuracy bar in infinite mode
  }

  // Set the initial question progress text
  questionProgress.textContent = mode === "quiz" ? `Question 1 of ${quiz.length}` : "";

  // Update the score info based on mode
  scoreInfo.textContent = mode === "infinite" ? `Score: ${score}` : `Score: 0 / ${quiz.length}`;
}


function showQuestion(quiz) {
    choicesDiv.innerHTML = "";
    explanationDiv.classList.add("hidden");
    resultMsg.textContent = "";

    let q;
    if (mode === "infinite") {
        const unchecked = quiz.filter(item => !infiniteChecked[item.question]);
        q = unchecked.length > 0
            ? unchecked[Math.floor(Math.random() * unchecked.length)]
            : quiz[Math.floor(Math.random() * quiz.length)];
        tempAnswer = null;
    } else {
        q = quiz[index];
    }

    questionText.textContent = q.question;
    if (q.image) {
        questionImage.src = q.image;
        questionImage.style.display = "block";
    } else {
        questionImage.src = "";
        questionImage.style.display = "none";
    }

    const alreadyChecked = mode === "infinite" ? false : checked[index];
    answered = alreadyChecked;

    checkBtn.classList.add("hidden"); // hide by default, we'll show if needed

    q.choices.forEach((choice, i) => {
        const btn = document.createElement("button");
        btn.className = "choice-btn";

        if (typeof choice === 'string') {
            btn.textContent = choice;
        } else if (choice.image) {
            const img = document.createElement("img");
            img.src = choice.image;
            img.alt = "Choice image";
            img.style.maxWidth = "150px";
            btn.appendChild(img);
        }

        // Highlight if previously selected
        if (mode !== "infinite" && userAnswers[index] === i) {
            btn.classList.add("selected");

            // If the question hasn’t been checked yet, show the check button
            if (!alreadyChecked) {
                checkBtn.dataset.choice = i;
                checkBtn.dataset.answer = q.answer;
                checkBtn.dataset.explanation = q.explanation;
                checkBtn.classList.remove("hidden");
            }
        }

        // Disable buttons only if question has been checked
        btn.disabled = alreadyChecked;

        btn.addEventListener("click", () => selectAnswer(btn, i, q.answer, q.explanation));

        choicesDiv.appendChild(btn);
    });

    // Show explanation if already checked
    if (alreadyChecked && mode === "quiz") {
        explanationDiv.classList.remove("hidden");
        explanationDiv.textContent = q.explanation;
    }

    // Update buttons and progress
    if (mode === "quiz") {
        prevBtn.style.display = index > 0 ? "inline-block" : "none";
        updateProgressBar();
        updateNavigationButtons();
    } else {
        prevBtn.style.display = "none";
        nextBtn.style.display = "inline-block";
    }
}



// ===== Select Answer =====
function selectAnswer(btn, choiceIndex, correctAnswer, explanation) {
    if (answered) return;

    // Unselect other buttons
    document.querySelectorAll(".choice-btn").forEach(b => b.classList.remove("selected"));
    btn.classList.add("selected");

    if (mode === "infinite") {
        tempAnswer = choiceIndex;
    } else {
        userAnswers[index] = choiceIndex;
        checked[index] = false;
    }

    checkBtn.dataset.choice = choiceIndex;
    checkBtn.dataset.answer = correctAnswer;
    checkBtn.dataset.explanation = explanation;

    checkBtn.classList.remove("hidden");
}



// ===== Check Answer (in Infinite Mode) =====
// ===== Next Button (Only in Infinite Mode) =====
nextBtn.onclick = () => {
    if (mode === "infinite") {
        // If no answer is selected, treat it as skipped (increment totalAnswered but no score)
        if (tempAnswer === null) {
            resultMsg.textContent = "❌ Skipped! Correct answer: Not answered.";
            resultMsg.style.color = "red";
            // Increment totalAnswered for skipped questions
            totalAnswered++;

            // Update accuracy bar (this skipped question is considered wrong)
            updateAccuracyBar();
        } else {
            // If an answer was selected, treat it as a regular answer
            const currentQ = infinitePool.find(item => item.question === questionText.textContent);
            if (tempAnswer === currentQ.answer) {
                score++; // Increment score if the answer is correct
            }
            // Increment totalAnswered for answered questions (whether correct or incorrect)
            totalAnswered++;
        }

        // Update score display
        scoreInfo.textContent = `Score: ${score} / ${totalAnswered}`;

        // Reset tempAnswer for the next question
        tempAnswer = null;

        // Pick a new random question (ensure it's not already answered)
        const unchecked = infinitePool.filter(item => !infiniteChecked[item.question]);
        const randomQ = unchecked.length > 0 ? unchecked[Math.floor(Math.random() * unchecked.length)] : infinitePool[Math.floor(Math.random() * infinitePool.length)];
        showQuestion([randomQ]);

        // Update the accuracy bar after each question
        updateAccuracyBar();

        return;
    }

    // Normal quiz mode (same as before)
    calculateQuizScore();
    index++;
    if (index >= currentQuiz.length) finishQuiz();
    else showQuestion(currentQuiz);
};

// ===== Show Question =====

function showQuestion(quiz) {
    choicesDiv.innerHTML = "";
    explanationDiv.classList.add("hidden");
    resultMsg.textContent = "";

    let q;
    if (mode === "infinite") {
        const unchecked = quiz.filter(item => !infiniteChecked[item.question]);
        q = unchecked.length > 0
            ? unchecked[Math.floor(Math.random() * unchecked.length)]
            : quiz[Math.floor(Math.random() * quiz.length)];
        tempAnswer = null;
    } else {
        q = quiz[index];
    }

    questionText.textContent = q.question;
    if (q.image) {
        questionImage.src = q.image;
        questionImage.style.display = "block";
    } else {
        questionImage.src = "";
        questionImage.style.display = "none";
    }

    const alreadyChecked = mode === "infinite" ? false : checked[index];
    answered = alreadyChecked;

    checkBtn.classList.add("hidden"); // hide by default, we'll show if needed

    q.choices.forEach((choice, i) => {
        const btn = document.createElement("button");
        btn.className = "choice-btn";

        if (typeof choice === 'string') {
            btn.textContent = choice;
        } else if (choice.image) {
            const img = document.createElement("img");
            img.src = choice.image;
            img.alt = "Choice image";
            img.style.maxWidth = "150px";
            btn.appendChild(img);
        }

        // Highlight if previously selected
        if (mode !== "infinite" && userAnswers[index] === i) {
            btn.classList.add("selected");

            // If the question hasn’t been checked yet, show the check button
            if (!alreadyChecked) {
                checkBtn.dataset.choice = i;
                checkBtn.dataset.answer = q.answer;
                checkBtn.dataset.explanation = q.explanation;
                checkBtn.classList.remove("hidden");
            }
        }

        // Disable buttons only if question has been checked
        btn.disabled = alreadyChecked;

        btn.addEventListener("click", () => selectAnswer(btn, i, q.answer, q.explanation));

        choicesDiv.appendChild(btn);
    });

    // Show explanation if already checked
    if (alreadyChecked && mode === "quiz") {
        explanationDiv.classList.remove("hidden");
        explanationDiv.textContent = q.explanation;
    }

    // Update buttons and progress
    if (mode === "quiz") {
        prevBtn.style.display = index > 0 ? "inline-block" : "none";
        updateProgressBar();
        updateNavigationButtons();
    } else {
        prevBtn.style.display = "none";
        nextBtn.style.display = "inline-block";
    }
}




function updateAccuracyBar() {
    const accuracy = totalAnswered > 0 ? (score / totalAnswered) * 100 : 0;
    const bar = document.getElementById('accuracyBar');

    // Update width
    bar.style.width = `${accuracy}%`;

    // Remove old color classes
    bar.classList.remove('green', 'yellow', 'red');

    let emoji = '';

    if (accuracy >= 80) {
        bar.classList.add('green');
        emoji = '🏆';
    } else if (accuracy >= 50) {
        bar.classList.add('yellow');
        emoji = '🔥';
    } else {
        bar.classList.add('red');
        emoji = '⚠️';
    }

    // Update text inside the bar
    bar.textContent = `${emoji} ${Math.round(accuracy)}%`;
}






// ===== Prev Button =====
prevBtn.onclick = () => {
  if (mode !== "quiz" || index === 0) return;
  index--;
  showQuestion(currentQuiz);
}


// ===== Update Progress Bar =====
function updateProgressBar() {
  if (mode !== "quiz") return;
  const progressPercent = ((index + 1) / currentQuiz.length) * 100;
  progressFill.style.width = `${progressPercent}%`;
  questionProgress.textContent = `Question ${index + 1} of ${currentQuiz.length}`;
}

// ===== Calculate Quiz Score =====
function calculateQuizScore() {
  score = 0;
  for (let i = 0; i < currentQuiz.length; i++) {
    if (userAnswers[i] === currentQuiz[i].answer) score++;
  }
  if (mode === "quiz") scoreInfo.textContent = `${score} / ${currentQuiz.length}`;
}

function startInfiniteTimer() {
    clearInterval(infiniteTimerInterval);
    infiniteTime = 0; // start at 0
    updateInfiniteTimerDisplay();

    infiniteTimerInterval = setInterval(() => {
        infiniteTime++;
        updateInfiniteTimerDisplay();
    }, 1000);
}

function updateInfiniteTimerDisplay() {
    const m = String(Math.floor(infiniteTime / 60)).padStart(2, "0");
    const s = String(infiniteTime % 60).padStart(2, "0");
    timerDiv.textContent = `${m}:${s}`;
}

function stopInfiniteTimer() {
    clearInterval(infiniteTimerInterval);
}




