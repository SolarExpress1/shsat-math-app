const CACHE_NAME = "shsat-v1";
const FILES_TO_CACHE = [
  "index.html",        // your HTML file
  "style.css",        // your CSS file
  "script.js",       // your JS file
  "manifest.json",
  "180x180.png",
  "192x192.png",
  "512x512.png"
];

// Install event - caches files
self.addEventListener("install", event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(FILES_TO_CACHE))
  );
  self.skipWaiting();
});

// Activate event - cleans old caches if needed
self.addEventListener("activate", event => {
  event.waitUntil(
    caches.keys().then(keyList =>
      Promise.all(
        keyList.map(key => {
          if (key !== CACHE_NAME) {
            return caches.delete(key);
          }
        })
      )
    )
  );
  self.clients.claim();
});

// Fetch event - serves cached files if offline
self.addEventListener("fetch", event => {
  event.respondWith(
    caches.match(event.request).then(response => {
      return response || fetch(event.request);
    })
  );
});
