# shsat 6-7 (2)

A Pen created on CodePen.

Original URL: [https://codepen.io/Thanima-the-sans/pen/ZYOGPPO](https://codepen.io/Thanima-the-sans/pen/ZYOGPPO).

